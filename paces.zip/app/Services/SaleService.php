<?php

namespace App\Services;

use App\Models\Customer;
use App\Models\Location;
use App\Models\Product;
use App\Models\PurchaseProduct;
use App\Models\Sale;
use App\Models\SaleEditLog;
use App\Models\SaleLine;
use App\Models\SalePayment;
use App\Models\StockMovement;
use App\Repositories\SaleRepository;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;

/**
 * Sale orchestration. Owns:
 *
 *   - transactional create / update / status transitions
 *   - sale number generation (global per-month sequence)
 *   - line + payment money math (server is source of truth)
 *   - payment status / balance recalculation
 *
 * The lines table IS the outgoing-stock ledger:
 *   on_hand = SUM(purchase_products.qty WHERE posted)
 *           − SUM(sale_lines.qty WHERE sale.status IN (posted, completed))
 *
 * That query lives elsewhere (a future Stock reporter); this service
 * just makes sure the data shape stays correct.
 */
class SaleService
{
    public function __construct(
        private SaleRepository $repo,
        private StockService   $stock,
    ) {}

    /* ─── Public API ───────────────────────────────────────── */

    /**
     * Create a new sale from the validated request payload.
     *
     * Extra keys accepted when called from SaleImportService:
     *   'external_ref'      => string|null
     *   'external_order_id' => string|null
     *   'import_batch_id'   => string|null  (UUID)
     *
     * These are stamped inside the same transaction so traceability
     * columns are always set atomically with the sale record.
     */
    public function create(array $data): Sale
    {
        return DB::transaction(function () use ($data) {
            $customer = Customer::findOrFail($data['customer_id']);
            $location = Location::findOrFail($data['location_id']);
            $date     = Carbon::parse($data['sale_date'] ?? now()->toDateString());

            $sale = new Sale();
            $sale->sale_number     = Sale::generateSaleNumber($date);
            $sale->sale_date       = $date->toDateString();
            $sale->customer_id     = $customer->id;
            $sale->location_id     = $location->id;
            $sale->channel_id      = $data['channel_id']      ?? null;
            $sale->salesperson_id  = $data['salesperson_id']  ?? auth()->id();
            $sale->tax_type        = $data['tax_type']        ?? Sale::TAX_NONE;
            $sale->shipping_charge = (float) ($data['shipping_charge'] ?? 0);
            $sale->note            = $data['note']            ?? null;

            // Import traceability — only set when called from SaleImportService.
            // Ignored for regular terminal sales (keys simply absent).
            if (array_key_exists('external_ref', $data)) {
                $sale->external_ref = $data['external_ref'] ?: null;
            }
            if (array_key_exists('external_order_id', $data)) {
                $sale->external_order_id = $data['external_order_id'] ?: null;
            }
            if (array_key_exists('import_batch_id', $data)) {
                $sale->import_batch_id = $data['import_batch_id'] ?: null;
            }

            // Start as DRAFT so we can build lines + payments first,
            // then run the stock check, THEN transition to the intended
            // status. This keeps the availability error path clean
            // (we never have a half-posted sale with no movements).
            $intendedStatus = $data['status'] ?? Sale::STATUS_DRAFT;
            $sale->status   = Sale::STATUS_DRAFT;
            $sale->save();

            $this->syncLines($sale, $data['lines'] ?? []);
            $this->syncPayments($sale, $data['payments'] ?? [], replace: true);
            $this->recalculate($sale);

            // Apply the real status. post() and complete() both call
            // recordSalePosting() which runs the availability check.
            if ($intendedStatus === Sale::STATUS_POSTED) {
                $this->post($sale);
            } elseif ($intendedStatus === Sale::STATUS_COMPLETED) {
                $this->post($sale);
                $sale->refresh();
                $this->complete($sale);
            }

            return $this->repo->refresh($sale);
        });
    }

    /**
     * Update an existing sale.
     *
     *   - Draft   : full line-item re-save; no stock impact.
     *   - Posted  : full line-item re-save WITH ledger sync — the old OUT
     *               movements are reversed and fresh ones booked for the
     *               rebuilt lines (see updatePostedLines). Only reachable
     *               within the configurable edit window; the controller
     *               gates this via Sale::editBlockReason().
     *   - Other   : defensive note/shipping-only fallback (the controller
     *               gate normally prevents reaching here at all).
     *
     * sale_date, sale_number and customer_id are NEVER changed by an edit —
     * they're locked once the sale exists. Existing payments are preserved.
     *
     * Every successful edit writes a SaleEditLog row (who / when / diff).
     */
    public function update(Sale $sale, array $data): Sale
    {
        return DB::transaction(function () use ($sale, $data) {
            $before = $this->editSnapshot($sale);

            if ($sale->isPosted() || $sale->isCompleted()) {
                $this->updatePostedLines($sale, $data);
            } elseif ($sale->isDraft()) {
                $this->updateDraftLines($sale, $data);
            } else {
                // Defensive: refunded / cancelled — note + shipping only.
                $sale->note            = $data['note']            ?? $sale->note;
                $sale->shipping_charge = (float) ($data['shipping_charge'] ?? $sale->shipping_charge);
                $sale->save();
                $this->recalculate($sale);
            }

            $this->logEdit($sale, $before);

            return $this->repo->refresh($sale);
        });
    }

    /**
     * Draft re-save: rebuild lines from scratch (safe — drafts have no
     * stock movements). sale_date and customer stay locked.
     */
    private function updateDraftLines(Sale $sale, array $data): void
    {
        $sale->location_id     = $data['location_id']     ?? $sale->location_id;
        $sale->channel_id      = array_key_exists('channel_id', $data) ? $data['channel_id'] : $sale->channel_id;
        $sale->salesperson_id  = $data['salesperson_id']  ?? $sale->salesperson_id;
        $sale->tax_type        = $data['tax_type']        ?? $sale->tax_type;
        $sale->shipping_charge = (float) ($data['shipping_charge'] ?? 0);
        $sale->note            = $data['note']            ?? null;

        // Hard reset of children — simplest correct strategy for drafts.
        $sale->lines()->each(fn(SaleLine $l) => $l->forceDelete());
        $sale->save();

        $this->syncLines($sale, $data['lines'] ?? []);
        // Only touch payments if the caller actually sent them, so the edit
        // form (which omits payments) never wipes existing ones.
        if (array_key_exists('payments', $data)) {
            $this->syncPayments($sale, $data['payments'], replace: true);
        }
        $this->recalculate($sale);
    }

    /**
     * Posted re-save with stock-ledger sync. Mirrors PurchaseService::
     * updatePostedLines() in spirit: reverse the current OUT movements,
     * soft-delete the old lines (kept as ledger FK targets), rebuild from
     * the new payload, then book fresh OUT movements for the new lines.
     *
     * Payments are preserved; sale_date and customer stay locked. If the
     * rebuilt lines can't be covered by stock, recordSalePostingForEdit()
     * throws and the whole transaction rolls back.
     */
    private function updatePostedLines(Sale $sale, array $data): void
    {
        $sale->load('lines');
        $oldLineIds = $sale->lines->pluck('id')->all();

        // 1. Return the old stock to the pool.
        $this->stock->reverseSaleForEdit($sale, $oldLineIds);

        // 2. Soft-delete the old lines (movements still reference them).
        $sale->lines()->each(fn(SaleLine $l) => $l->delete());

        // 3. Header fields (sale_date + customer intentionally locked).
        $sale->location_id     = $data['location_id']     ?? $sale->location_id;
        $sale->channel_id      = array_key_exists('channel_id', $data) ? $data['channel_id'] : $sale->channel_id;
        $sale->salesperson_id  = $data['salesperson_id']  ?? $sale->salesperson_id;
        $sale->tax_type        = $data['tax_type']        ?? $sale->tax_type;
        $sale->shipping_charge = (float) ($data['shipping_charge'] ?? 0);
        $sale->note            = $data['note']            ?? null;
        $sale->save();

        // 4. Rebuild lines + totals (balance recomputed vs existing payments).
        $this->syncLines($sale, $data['lines'] ?? []);
        $this->recalculate($sale);

        // A completed sale that now carries an outstanding balance (e.g. the
        // edit raised the total above what was paid) can no longer be
        // "completed" — step it back to posted so the status stays truthful.
        if ($sale->isCompleted() && (float) $sale->balance_due > 0.0001) {
            $sale->status = Sale::STATUS_POSTED;
            $sale->save();
        }

        // 5. Book fresh OUT movements for the new lines.
        $this->stock->recordSalePostingForEdit($sale);
    }

    /* ─── Edit logging ────────────────────────── */

    private function editSnapshot(Sale $sale): array
    {
        $sale->loadMissing('lines');

        return [
            'tax_type'        => $sale->tax_type,
            'location_id'     => $sale->location_id,
            'channel_id'      => $sale->channel_id,
            'salesperson_id'  => $sale->salesperson_id,
            'shipping_charge' => (float) $sale->shipping_charge,
            'note'            => $sale->note,
            'grand_total'     => (float) $sale->grand_total,
            'line_count'      => $sale->lines->count(),
        ];
    }

    private function logEdit(Sale $sale, array $before): void
    {
        $after = $this->editSnapshot($sale->fresh());

        $changes = [];
        foreach ($before as $field => $oldValue) {
            $newValue = $after[$field] ?? null;
            if ($oldValue !== $newValue) {
                $changes[$field] = ['from' => $oldValue, 'to' => $newValue];
            }
        }

        SaleEditLog::create([
            'sale_id'    => $sale->id,
            'user_id'    => auth()->id(),
            'action'     => 'updated',
            'changes'    => $changes ?: null,
            'ip_address' => request()->ip(),
        ]);
    }

    /* ─── Status transitions ──────────────────────────────── */

    public function post(Sale $sale): Sale
    {
        if ($sale->isPosted() || $sale->isCompleted()) {
            return $sale;
        }
        if ($sale->isCancelled() || $sale->isRefunded()) {
            throw new InvalidArgumentException('Cannot post a cancelled or refunded sale.');
        }
        if ($sale->lines()->count() === 0) {
            throw new InvalidArgumentException('Cannot post an empty sale.');
        }

        return DB::transaction(function () use ($sale) {
            // Hard stock check + ledger writes. Throws RuntimeException
            // if any line can't be filled — the surrounding transaction
            // ensures we never end up with status=posted but no movements.
            $this->stock->recordSalePosting($sale);

            $sale->status = Sale::STATUS_POSTED;
            $sale->save();

            return $this->repo->refresh($sale);
        });
    }

    /**
     * Mark a posted sale as completed. Reached when the customer has
     * been fully paid AND delivered (the UI calls this).
     */
    public function complete(Sale $sale): Sale
    {
        if (! $sale->isPosted()) {
            throw new InvalidArgumentException('Only posted sales can be completed.');
        }
        if ((float) $sale->balance_due > 0.0001) {
            throw new InvalidArgumentException('Cannot complete a sale with an outstanding balance.');
        }

        $sale->status = Sale::STATUS_COMPLETED;
        $sale->save();

        return $this->repo->refresh($sale);
    }

    public function refund(Sale $sale): Sale
    {
        if ($sale->isDraft() || $sale->isCancelled()) {
            throw new InvalidArgumentException('Only posted or completed sales can be refunded.');
        }

        return DB::transaction(function () use ($sale) {
            $this->stock->reverseSalePosting($sale, StockMovement::REASON_SALE_RETURN);
            $sale->status = Sale::STATUS_REFUNDED;
            $sale->save();
            return $this->repo->refresh($sale);
        });
    }

    public function cancel(Sale $sale): Sale
    {
        if ($sale->isCompleted() || $sale->isRefunded()) {
            throw new InvalidArgumentException('Completed or refunded sales cannot be cancelled.');
        }

        return DB::transaction(function () use ($sale) {
            if ($sale->isPosted()) {
                $this->stock->reverseSalePosting($sale, StockMovement::REASON_SALE_CANCEL);
            }
            $sale->status = Sale::STATUS_CANCELLED;
            $sale->save();
            return $this->repo->refresh($sale);
        });
    }

    /**
     * Delete a sale entirely. If it has active OUT movements booked
     * (posted or completed — both go through post(), which is the only
     * place recordSalePosting() runs), they're reversed first via the
     * same call cancel() makes — StockService::reverseSalePosting()
     * with REASON_SALE_CANCEL — so no OUT movement is left dangling
     * against a sale that's about to disappear. Refunded/cancelled sales
     * already had their stock settled by refund()/cancel() and are left
     * alone here (reverseSalePosting() is idempotent per-reason, but
     * calling it with a DIFFERENT reason than what already ran would
     * double-credit the stock, so status gates which sales need it
     * rather than calling it unconditionally). Drafts never had
     * movements booked at all.
     */
    public function delete(Sale $sale): void
    {
        DB::transaction(function () use ($sale) {
            if ($sale->isPosted() || $sale->isCompleted()) {
                $this->stock->reverseSalePosting($sale, StockMovement::REASON_SALE_CANCEL);
            }

            $sale->lines()->each(fn(SaleLine $l) => $l->delete());
            $sale->payments()->each(fn(SalePayment $p) => $p->delete());
            $sale->delete();
        });
    }

    /* ─── Payment helpers (public for the show page) ──────── */

    public function addPayment(Sale $sale, array $data): SalePayment
    {
        return DB::transaction(function () use ($sale, $data) {
            $payment = new SalePayment([
                'payment_date'     => $data['payment_date']     ?? now()->toDateString(),
                'amount'           => (float) ($data['amount']  ?? 0),
                'payment_method'   => $data['payment_method']   ?? SalePayment::METHOD_CASH,
                'reference_number' => $data['reference_number'] ?? null,
                'notes'            => $data['notes']            ?? null,
            ]);
            $sale->payments()->save($payment);
            $this->recalculatePayments($sale);
            return $payment->refresh();
        });
    }

    public function removePayment(SalePayment $payment): void
    {
        DB::transaction(function () use ($payment) {
            $sale = $payment->sale;
            $payment->delete();
            if ($sale) {
                $this->recalculatePayments($sale);
            }
        });
    }

    /* ─── Internals ────────────────────────────────────────── */

    private function syncLines(Sale $sale, array $lines): void
    {
        foreach ($lines as $row) {
            /** @var Product $product */
            $product = Product::findOrFail($row['product_id']);

            $qty             = max(1, (int) ($row['qty'] ?? 1));
            $unitPrice       = (float) ($row['unit_price'] ?? 0);
            $taxPercent      = (float) ($row['tax_percent'] ?? 0);
            $discountPercent = (float) ($row['discount_percent'] ?? 0);

            $gross          = $qty * $unitPrice;
            $discountAmount = round($gross * $discountPercent / 100, 2);
            $taxableBase    = $gross - $discountAmount;
            $taxAmount      = round($taxableBase * $taxPercent / 100, 2);
            $total          = round($taxableBase + $taxAmount, 2);

            $costPrice         = 0.0;
            $purchaseProductId = $row['purchase_product_id'] ?? null;
            if ($purchaseProductId) {
                $pp = PurchaseProduct::find($purchaseProductId);
                if ($pp) {
                    $costPrice = (float) $pp->price;
                }
            }

            $line = new SaleLine([
                'product_id'          => $product->id,
                'purchase_product_id' => $purchaseProductId,
                'barcode'             => $row['barcode'] ?? null,
                'qty'                 => $qty,
                'unit_price'          => $unitPrice,
                'tax_percent'         => $taxPercent,
                'tax_amount'          => $taxAmount,
                'discount_percent'    => $discountPercent,
                'discount_amount'     => $discountAmount,
                'subtotal'            => round($gross, 2),
                'total'               => $total,
                'cost_price'          => $costPrice,
                'notes'               => $row['notes'] ?? null,
            ]);

            $sale->lines()->save($line);
        }
    }

    private function syncPayments(Sale $sale, array $payments, bool $replace = false): void
    {
        if ($replace) {
            $sale->payments()->each(fn(SalePayment $p) => $p->forceDelete());
        }

        foreach ($payments as $row) {
            $amount = (float) ($row['amount'] ?? 0);
            if (abs($amount) < 0.001) {
                continue;
            }

            $sale->payments()->save(new SalePayment([
                'payment_date'     => $row['payment_date']     ?? $sale->sale_date->toDateString(),
                'amount'           => $amount,
                'payment_method'   => $row['payment_method']   ?? SalePayment::METHOD_CASH,
                'reference_number' => $row['reference_number'] ?? null,
                'notes'            => $row['notes']            ?? null,
            ]));
        }
    }

    private function recalculate(Sale $sale): void
    {
        $subtotal = 0.0;
        $tax      = 0.0;
        $discount = 0.0;

        foreach ($sale->lines()->get() as $line) {
            $subtotal += (float) $line->subtotal;
            $tax      += (float) $line->tax_amount;
            $discount += (float) $line->discount_amount;
        }

        $shipping = (float) $sale->shipping_charge;
        $grand    = $subtotal - $discount + $tax + $shipping;

        $sale->subtotal       = round($subtotal, 2);
        $sale->discount_total = round($discount, 2);
        $sale->tax_total      = round($tax, 2);
        $sale->grand_total    = round($grand, 2);
        $sale->save();

        $this->recalculatePayments($sale);
    }

    private function recalculatePayments(Sale $sale): void
    {
        $paid  = (float) $sale->payments()->sum('amount');
        $grand = (float) $sale->grand_total;

        $balance = round(max(0, $grand - $paid), 2);

        if ($paid <= 0.0001) {
            $status = Sale::PAY_UNPAID;
        } elseif ($paid + 0.0001 >= $grand) {
            $status = Sale::PAY_PAID;
        } else {
            $status = Sale::PAY_PARTIAL;
        }

        $sale->paid_amount    = round($paid, 2);
        $sale->balance_due    = $balance;
        $sale->payment_status = $status;
        $sale->save();
    }
}
